"use strict";module.exports=(e,o)=>o({url:"/longaudio/v1/home_new/daily_recommend",method:"post",encryptType:"android",params:{module_id:1,size:e.pagesize||30,page:e.page||1},cookie:e?.cookie||{}});
