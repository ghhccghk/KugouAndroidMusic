"use strict";module.exports=(o,i)=>i({url:"/grow/v1/song_ranking/play_page/ranking_info",method:"GET",params:{album_audio_id:o.album_audio_id},encryptType:"android",cookie:o?.cookie||{}});
