"use strict";module.exports=(a,e)=>e({url:"/api/v3/search/hot_tab",method:"GET",params:{navid:1,plat:2},encryptType:"android",cookie:a?.cookie||{},headers:{"x-router":"msearch.kugou.com"}});
