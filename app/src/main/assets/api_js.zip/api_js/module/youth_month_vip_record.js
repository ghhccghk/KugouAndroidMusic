"use strict";module.exports=(e,o)=>o({url:"/youth/v1/activity/get_month_vip_record",encryptType:"android",method:"get",cookie:e?.cookie});
