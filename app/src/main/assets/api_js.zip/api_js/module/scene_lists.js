"use strict";module.exports=(e,o)=>o({url:"/scene/v1/scene/list",method:"GET",encryptType:"android",cookie:e?.cookie||{}});
