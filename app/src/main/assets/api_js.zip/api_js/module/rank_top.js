"use strict";module.exports=(e,r)=>r({url:"/mobileservice/api/v5/rank/rec_rank_list",method:"get",encryptType:"android",cookie:e?.cookie||{}});
