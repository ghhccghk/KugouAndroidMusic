"use strict";module.exports=(e,o)=>o({url:"/youth/v3/user/get_dynamic",encryptType:"android",method:"get",cookie:e?.cookie});
