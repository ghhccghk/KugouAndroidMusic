"use strict";module.exports=(e,o)=>o({url:"/youth/v1/recharge/receive_vip_listen_song",encryptType:"android",method:"post",params:{source_id:90137},cookie:e?.cookie});
