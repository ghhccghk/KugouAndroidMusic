"use strict";module.exports=(o,e)=>e({url:"/count/v1/audio/mget_collect",method:"GET",encryptType:"android",cookie:o?.cookie||{},params:{mixsongids:o.mixsongids}});
