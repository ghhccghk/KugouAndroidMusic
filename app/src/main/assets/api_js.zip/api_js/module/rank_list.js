"use strict";module.exports=(o,t)=>{let e={plat:2,withsong:o.withsong||1,parentid:0};return t({url:"/ocean/v6/rank/list",method:"get",encryptType:"android",params:e,cookie:o?.cookie||{}})};
