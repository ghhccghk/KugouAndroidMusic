"use strict";module.exports=(t,a)=>a({url:"/pubsongs/v1/get_tags_by_type",method:"POST",encryptType:"android",data:{tag_type:"collection",tag_id:0,source:3},cookie:t?.cookie||{}});
