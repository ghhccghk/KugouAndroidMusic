"use strict";module.exports=(o,e)=>e({url:"/youth/api/amway/v2/index",encryptType:"android",method:"get",params:{global_collection_id:o.global_collection_id},cookie:o?.cookie});
