"use strict";module.exports=(e,o)=>o({url:"/scene/v1/scene/module",params:{scene_id:e.id},method:"POST",encryptType:"android",cookie:e?.cookie||{}});
