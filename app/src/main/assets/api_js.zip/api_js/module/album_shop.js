"use strict";module.exports=(a,e)=>e({url:"/zhuanjidata/v3/album_shop_v2/get_classify_data",method:"GET",encryptType:"android",cookie:a?.cookie||{}});
