"use strict";module.exports=(e,o)=>o({url:"/scene/v1/scene/module_info",params:{scene_id:e.id,module_id:e.module_id},method:"GET",encryptType:"android",cookie:e?.cookie||{}});
