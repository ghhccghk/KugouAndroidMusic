"use strict";module.exports=(e,o)=>o({url:"/youth/v2/channel/channel_all_list",encryptType:"android",method:"get",params:{page:e.page||1,pagesize:e.pagesize||30,type:1},cookie:e?.cookie});
