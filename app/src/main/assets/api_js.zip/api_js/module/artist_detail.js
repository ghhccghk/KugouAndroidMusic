"use strict";module.exports=(o,e)=>e({url:"/kmr/v3/author",method:"POST",data:{author_id:o.id},encryptType:"android",cookie:o?.cookie||{},headers:{"x-router":"openapi.kugou.com","kg-tid":36}});
